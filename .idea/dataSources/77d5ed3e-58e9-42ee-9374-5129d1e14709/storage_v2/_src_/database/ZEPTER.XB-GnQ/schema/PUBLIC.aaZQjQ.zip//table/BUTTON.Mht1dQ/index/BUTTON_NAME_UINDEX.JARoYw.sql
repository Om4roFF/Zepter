create index BUTTON_NAME_UINDEX
    on BUTTON (NAME, LANG_ID);

