create unique index COMPLAINTS_ID_UINDEX
    on COMPLAINTS (ID);

