create unique index LANG_ID_UINDEX
    on LANG (ID);

