create unique index KEYBOARD_ID_UINDEX
    on KEYBOARD (ID);

