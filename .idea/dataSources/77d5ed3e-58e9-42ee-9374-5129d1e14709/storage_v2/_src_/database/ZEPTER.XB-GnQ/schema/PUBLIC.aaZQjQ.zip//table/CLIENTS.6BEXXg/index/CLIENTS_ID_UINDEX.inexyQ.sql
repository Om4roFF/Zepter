create unique index CLIENTS_ID_UINDEX
    on CLIENTS (ID);

