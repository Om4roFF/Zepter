create unique index USER_ID_UINDEX
    on USER (ID);

