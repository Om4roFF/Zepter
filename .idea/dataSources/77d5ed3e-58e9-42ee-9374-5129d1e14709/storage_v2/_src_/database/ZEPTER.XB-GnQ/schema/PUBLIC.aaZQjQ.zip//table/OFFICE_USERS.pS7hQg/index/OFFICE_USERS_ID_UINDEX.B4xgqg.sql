create unique index OFFICE_USERS_ID_UINDEX
    on OFFICE_USERS (ID);

