create unique index LANG_NAME_UINDEX
    on LANG (NAME);

