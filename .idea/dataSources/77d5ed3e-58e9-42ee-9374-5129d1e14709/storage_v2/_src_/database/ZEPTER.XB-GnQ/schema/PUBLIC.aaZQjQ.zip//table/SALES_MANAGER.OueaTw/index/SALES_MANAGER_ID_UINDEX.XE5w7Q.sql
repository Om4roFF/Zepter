create unique index SALES_MANAGER_ID_UINDEX
    on SALES_MANAGER (ID);

