create unique index PROPERTIES_ID_UINDEX
    on PROPERTIES (ID);

