create index BUTTON_ID_UINDEX
    on BUTTON (ID, LANG_ID);

