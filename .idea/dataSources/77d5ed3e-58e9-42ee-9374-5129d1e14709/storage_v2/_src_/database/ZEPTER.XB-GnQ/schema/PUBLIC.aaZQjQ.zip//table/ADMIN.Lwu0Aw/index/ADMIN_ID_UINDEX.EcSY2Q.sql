create unique index ADMIN_ID_UINDEX
    on ADMIN (ID);

