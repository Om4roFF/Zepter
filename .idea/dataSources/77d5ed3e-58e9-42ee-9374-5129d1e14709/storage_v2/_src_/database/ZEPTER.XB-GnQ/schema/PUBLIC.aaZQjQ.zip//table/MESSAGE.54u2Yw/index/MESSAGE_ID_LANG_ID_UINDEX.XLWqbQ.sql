create unique index MESSAGE_ID_LANG_ID_UINDEX
    on MESSAGE (ID, LANG_ID);

