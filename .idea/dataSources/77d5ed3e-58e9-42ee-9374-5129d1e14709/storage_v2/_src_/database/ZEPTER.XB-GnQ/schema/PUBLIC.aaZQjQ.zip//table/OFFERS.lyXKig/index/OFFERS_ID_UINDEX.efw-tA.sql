create unique index OFFERS_ID_UINDEX
    on OFFERS (ID);

